﻿// File: DatabaseContext.cs
using Microsoft.EntityFrameworkCore;

namespace File_demo2.Model.Domain
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext(DbContextOptions<DatabaseContext> options) : base(options) { }
        public DbSet<Product> product { get; set; }
    }
}