﻿//// File: ProductController.cs
//using File_demo2.Model.Domain;
//using File_demo2.Repository.Abstract;
//using Microsoft.AspNetCore.Mvc;

//namespace File_demo2.Controllers
//{
//    [Route("api/[controller]/[action]")]
//    [ApiController]
//    public class ProductController : ControllerBase
//    {
//        private readonly IFileServer _fileServer;
//        private readonly IProductRepository _productRepository;

//        public ProductController(IFileServer fileServer, IProductRepository productRepository) =>
//            (_fileServer, _productRepository) = (fileServer, productRepository);

//        [HttpPost]
//        public IActionResult Add([FromForm] Product model)
//        {
//            if (!ModelState.IsValid) return Ok("Invalid data");

//            if (model.ImageFile != null)
//            {
//                var fileResult = _fileServer.SaveImage(model.ImageFile);
//                if (fileResult.Item1 == 1) model.ProductImage = fileResult.Item2;
//            }

//            var message = _productRepository.Add(model) ? "Added Successfully" : "Error Adding Product";
//            return Ok(message);
//        }

//        [HttpGet]
//        public IActionResult GetProductById(int id)
//        {
//            var product = _productRepository.GetById(id);
//            return product == null
//                ? NotFound(new { Message = "Product not found" })
//                : Ok(new { product.Id, product.Name, product.ProductImage });
//        }
//    }
//}

//using Microsoft.AspNetCore.Mvc;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Hosting;
//using Microsoft.EntityFrameworkCore;

//using System;
//using System.IO;
//using System.Threading.Tasks;
//using File_demo2.Model.Domain;

//namespace File_demo2.Controllers
//{
//    [Route("api/[controller]/[action]")]
//    [ApiController]
//    public class ProductController : ControllerBase
//    {
//        private readonly IWebHostEnvironment _env;
//        private readonly DatabaseContext _context;


//        // Constructor to inject DbContext and IWebHostEnvironment
//        public ProductController(DatabaseContext context, IWebHostEnvironment env)
//        {
//            _context = context;
//            _env = env;
//        }

//        // HTTP POST action to add a new product
//        [HttpPost]
//        public async Task<IActionResult> Add([FromForm] Product model)
//        {
//            // Check if the model is valid
//            if (!ModelState.IsValid)
//                return Ok("Invalid data");

//            // Check if there's an image to save
//            if (model.ImageFile != null)
//            {
//                try
//                {
//                    var path = Path.Combine(_env.ContentRootPath, "Uploads");
//                    Directory.CreateDirectory(path); // Ensure the folder exists
//                    var filePath = Path.Combine(path, $"{Guid.NewGuid()}{Path.GetExtension(model.ImageFile.FileName)}");

//                    // Save the file to the server
//                    using (var stream = new FileStream(filePath, FileMode.Create))
//                    {
//                        await model.ImageFile.CopyToAsync(stream);
//                    }

//                    model.ProductImage = Path.GetFileName(filePath); // Store the image file name
//                }
//                catch
//                {
//                    return Ok("Error occurred while saving the image.");
//                }
//            }

//            // Add the product to the database
//            _context.product.Add(model);
//            await _context.SaveChangesAsync();

//            return Ok("Product Added Successfully");
//        }

//        // HTTP GET action to retrieve all products
//        [HttpGet]
//        public async Task<IActionResult> GetAllProducts()
//        {
//            var products = await _context.product.ToListAsync();
//            return Ok(products);
//        }


//        [HttpGet]
//        public IActionResult GetProductById(int id)
//        {
//            var product = _productRepository.GetById(id);
//            return product == null
//                ? NotFound(new { Message = "Product not found" })
//                : Ok(new { product.Id, product.Name, product.ProductImage });
//        }


//    }

//    // Product model class to bind the data

//}


using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using File_demo2.Model.Domain;
using System;
using System.IO;
using System.Threading.Tasks;

namespace File_demo2.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IWebHostEnvironment _env;
        private readonly DatabaseContext _context;

        // Constructor to inject DbContext and IWebHostEnvironment
        public ProductController(DatabaseContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        // HTTP POST action to add a new product
        [HttpPost]
        public async Task<IActionResult> Add([FromForm] Product model)
        {
            // Check if the model is valid
            if (!ModelState.IsValid)
                return Ok("Invalid data");

            // Check if there's an image to save
            if (model.ImageFile != null)
            {
                try
                {
                    var path = Path.Combine(_env.ContentRootPath, "Uploads");
                    Directory.CreateDirectory(path); // Ensure the folder exists
                    var filePath = Path.Combine(path, $"{Guid.NewGuid()}{Path.GetExtension(model.ImageFile.FileName)}");

                    // Save the file to the server
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await model.ImageFile.CopyToAsync(stream);
                    }

                    model.ProductImage = Path.GetFileName(filePath); // Store the image file name
                }
                catch
                {
                    return Ok("Error occurred while saving the image.");
                }
            }

            // Add the product to the database
            _context.product.Add(model);
            await _context.SaveChangesAsync();

            return Ok("Product Added Successfully");
        }

        
        [HttpGet]
        public async Task<IActionResult> GetAllProducts()
        {
            var products = await _context.product.ToListAsync();

            var result = products.Select(p => new
            {
                p.Id,
                p.Name,
                //ProductImageUrl = $"{Request.Scheme}://{Request.Host}/Uploads/{p.ProductImage}" ,
                ProductImageUrl = $"https://localhost:7180/Uploads/{p.ProductImage}"
            }).ToList();

            return Ok(result);
        }


        // HTTP GET action to retrieve a product by its ID
        [HttpGet]
        public async Task<IActionResult> GetProductById(int id)
        {
            var product = await _context.product.FindAsync(id);
            return product == null
                ? NotFound(new { Message = "Product not found" })
                : Ok(new { product.Id, product.Name, product.ProductImage });
        }
    }
}