﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using File_demo2.Model.Domain;
using PdfSharpCore.Pdf;
using TheArtOfDev.HtmlRenderer.PdfSharp;
using PdfSharpCore;

namespace File_demo2.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IWebHostEnvironment _env;
        private readonly DatabaseContext _context;

        // Constructor to inject DbContext and IWebHostEnvironment
        public ProductController(DatabaseContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        // HTTP POST action to add a new product
        [HttpPost]
        public async Task<IActionResult> Add([FromForm] Product model)
        {
            // Check if the model is valid
            if (!ModelState.IsValid)
                return Ok(new { message = "Invalid data" });

            // Check if there's an image to save
            if (model.ImageFile != null)
            {
                try
                {
                    var path = Path.Combine(_env.ContentRootPath, "Uploads");
                    Directory.CreateDirectory(path); // Ensure the folder exists
                    var filePath = Path.Combine(path, $"{Guid.NewGuid()}{Path.GetFileName(model.ImageFile.FileName)}");

                    // Save the file to the server
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await model.ImageFile.CopyToAsync(stream);
                    }

                    model.ProductImage = Path.GetFileName(filePath); // Store the image file name
                }
                catch
                {
                    return Ok(new { message ="Error occurred while saving the image." });
                }
            }

            // Add the product to the database
            _context.product.Add(model);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Product Added Successfully" });
        }


        // HTTP GET action to retrieve all products
        [HttpGet]
        public async Task<IActionResult> GetAllProducts()
        {
            var products = await _context.product.ToListAsync();

            var result = products.Select(p => new
            {
                p.Id,
                p.Name,
                ProductImageUrl = $"https://localhost:7180/Uploads/{p.ProductImage}"
            }).ToList();

            return Ok(result);
        }

        // HTTP GET action to retrieve a product by its ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetProductById(int id)
        {
            var product = await _context.product.FindAsync(id);

            if (product == null)
            {
                return NotFound(new { Message = "Product not found" });
            }

            var result = new
            {
                product.Id,
                product.Name,
                ProductImageUrl = $"https://localhost:7180/Uploads/{product.ProductImage}" // Constructing the full URL here
            };

            return Ok(result);
        }




        [HttpGet("{id}")]
        public async Task<IActionResult> GeneratePdf([FromRoute] int id)
        {
            var data = await _context.product.FindAsync(id);
            if (data == null)
            {
                return NotFound("No data found");
            }

            if (string.IsNullOrEmpty(data.ProductImage))
            {
                return NotFound("No image found.");
            }

            var ProductUrl = $"{Request.Scheme}://{Request.Host}/Uploads/{data.ProductImage}";


            var document = new PdfDocument();
            string htmlcontent = $@"
                <h1>Hello, Welcome</h1>
                <p>Name is {data.Name}</p>
                <img src='{ProductUrl}' width='100' height='100' />";

            PdfGenerator.AddPdfPages(document, htmlcontent, PageSize.A4);

            byte[] response;
            using (MemoryStream ms = new MemoryStream())
            {
                document.Save(ms);
                response = ms.ToArray();
            }

            string filename = $"person_{data.Id}.pdf";
            return File(response, "application/pdf", filename);
        }





        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromForm] Product model)
        {

            var detail = await _context.product.FindAsync(id);

            if (detail == null)
            {
                return NotFound(new { Message = "Product not found" });
            }


            detail.Name = model.Name;


            if (model.ImageFile != null)
            {
                try
                {

                    var oldImagePath = Path.Combine(_env.ContentRootPath, "Uploads", detail.ProductImage);
                    if (System.IO.File.Exists(oldImagePath))
                    {
                        System.IO.File.Delete(oldImagePath);
                    }

                    var path = Path.Combine(_env.ContentRootPath, "Uploads");
                    Directory.CreateDirectory(path);
                    var newFilePath = Path.Combine(path, $"{Guid.NewGuid()}{Path.GetExtension(model.ImageFile.FileName)}");

                    using (var stream = new FileStream(newFilePath, FileMode.Create))
                    {
                        await model.ImageFile.CopyToAsync(stream);
                    }


                    detail.ProductImage = Path.GetFileName(newFilePath);
                }
                catch (Exception ex)
                {
                    return BadRequest(new { Message = $"Error updating image: {ex.Message}" });
                }
            }


            await _context.SaveChangesAsync();

            return Ok(new { Message = "Product updated successfully", product = detail });
        }




        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var product = await _context.product.FindAsync(id);

            if (product == null)
            {
                return NotFound("Product Not found");
            }

            try
            {
                var imagepath = Path.Combine(_env.ContentRootPath, "Uploads", product.ProductImage);

                if (System.IO.File.Exists(imagepath))
                {
                    System.IO.File.Delete(imagepath);
                }

                _context.Remove(product);
                await _context.SaveChangesAsync();
                return Ok("Product deleted successfully");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}