﻿// File: ProductController.cs
using File_demo2.Model.Domain;
using File_demo2.Repository.Abstract;
using Microsoft.AspNetCore.Mvc;

namespace File_demo2.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IFileServer _fileServer;
        private readonly IProductRepository _productRepository;

        public ProductController(IFileServer fileServer, IProductRepository productRepository) =>
            (_fileServer, _productRepository) = (fileServer, productRepository);

        [HttpPost]
        public IActionResult Add([FromForm] Product model)
        {
            if (!ModelState.IsValid) return Ok("Invalid data");

            if (model.ImageFile != null)
            {
                var fileResult = _fileServer.SaveImage(model.ImageFile);
                if (fileResult.Item1 == 1) model.ProductImage = fileResult.Item2;
            }

            var message = _productRepository.Add(model) ? "Added Successfully" : "Error Adding Product";
            return Ok(message);
        }

        [HttpGet]
        public IActionResult GetProductById(int id)
        {
            var product = _productRepository.GetById(id);
            return product == null
                ? NotFound(new { Message = "Product not found" })
                : Ok(new { product.Id, product.Name, product.ProductImage });
        }
    }
}