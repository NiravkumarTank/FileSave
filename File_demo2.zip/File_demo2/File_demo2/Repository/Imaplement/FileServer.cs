﻿
// File: FileServer.cs
using File_demo2.Repository.Abstract;
using Microsoft.AspNetCore.Hosting;
using System.IO;

namespace File_demo2.Repository.Imaplement
{
    public class FileServer : IFileServer
    {
        private readonly IWebHostEnvironment _env;
        public FileServer(IWebHostEnvironment env) => _env = env;

        public Tuple<int, string> SaveImage(IFormFile imageFile)
        {
            try
            {
                var path = Path.Combine(_env.ContentRootPath, "Uploads");
                Directory.CreateDirectory(path);
                var filePath = Path.Combine(path, $"{Guid.NewGuid()}{Path.GetExtension(imageFile.FileName)}");

                using (var stream = new FileStream(filePath, FileMode.Create))
                    imageFile.CopyTo(stream);

                return new(1, Path.GetFileName(filePath));
            }
            catch { return new(0, "Error occurred."); }
        }

        public bool DeleteImage(string imageFileName)
        {
            try
            {
                var path = Path.Combine(_env.WebRootPath, "Uploads", imageFileName);
                if (File.Exists(path)) { File.Delete(path); return true; }
                return false;
            }
            catch { return false; }
        }
    }
}