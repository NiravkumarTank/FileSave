﻿// File: ProductRepository.cs
using File_demo2.Model.Domain;
using File_demo2.Repository.Abstract;
using Microsoft.EntityFrameworkCore;

namespace File_demo2.Repository.Imaplement
{
    public class ProductRepository : IProductRepository
    {
        private readonly DatabaseContext _context;
        public ProductRepository(DatabaseContext context) => _context = context;

        public bool Add(Product model)
        {
            try
            {   _context.product.Add(model);
                _context.SaveChanges();
                return true;
            }
            catch { return false; }
        }

        public Product GetById(int id) => _context.product.FirstOrDefault(p => p.Id == id);
    }
}