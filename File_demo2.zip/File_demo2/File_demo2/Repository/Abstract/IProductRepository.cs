﻿// File: IProductRepository.cs
using File_demo2.Model.Domain;

namespace File_demo2.Repository.Abstract
{
    public interface IProductRepository
    {
        bool Add(Product model);
        Product GetById(int id);
    }
}