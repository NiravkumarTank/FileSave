﻿namespace File_demo2.Repository.Abstract
{
    public interface IFileServer
    {
        public Tuple<int, string> SaveImage(IFormFile imageFile);
        public bool DeleteImage(string imageFileName);
    }
}
