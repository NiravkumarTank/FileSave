﻿using ADO.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace ADO.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class DetailsController : ControllerBase
    {
        private readonly string SqlConnetionstring = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Details_jQuery;Integrated Security=True;Trust Server Certificate=True";

        [HttpGet]
        public ActionResult<List<Details>> GetAll()
        {
            List<Details> details = new List<Details>();

            SqlConnection conn = new SqlConnection(SqlConnetionstring);

            string query = "Select * from [Details]";
            SqlCommand cmd = new SqlCommand(query, conn);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Details listItem = new Details
                {
                    Id = reader.GetInt32(0),
                    FirstName = reader.GetString(1),
                    LastName = reader.GetString(2),
                    Email = reader.GetString(3),
                    Password = reader.GetString(4),
                    Phone = reader.GetString(5),
                    Date = DateOnly.FromDateTime(reader.GetDateTime(6)),
                    Address = reader.GetString(7),
                    Sem = reader.GetString(8)
                };
                details.Add(listItem);
            }
            conn.Close();
            return Ok(details);
        }


        [HttpPost]
        public ActionResult<Details> AddData(Details details)
        {
            SqlConnection conn = new SqlConnection( SqlConnetionstring);
            string query = "insert into Details (FirstName,LastName,Email,Password,Phone,Date,Address,Sem)" +
                                " values (@fname,@lname,@email,@pws,@phone,@date,@address,@sem)";
            SqlCommand cmd = new SqlCommand(query, conn);
            conn.Open();
            cmd.Parameters.AddWithValue("@fname",details.FirstName);
            cmd.Parameters.AddWithValue("@lname", details.LastName);
            cmd.Parameters.AddWithValue("@email", details.Email);
            cmd.Parameters.AddWithValue("@pws", details.Password);
            cmd.Parameters.AddWithValue("@phone", details.Phone);
            cmd.Parameters.AddWithValue("@date", details.Date);
            cmd.Parameters.AddWithValue("@address", details.Address);
            cmd.Parameters.AddWithValue("@sem", details.Sem);
            cmd.ExecuteNonQuery();
            conn.Close();
            return Ok( new { message = "Data Add ", details });
        }



        [HttpGet]
        [Route("{id}")]
        public ActionResult<Details> GetById(int id)
        {
            SqlConnection conn = new SqlConnection(SqlConnetionstring);

            string query = "Select * from [Details] Where Id = @id";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@id", id);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                Details listItem = new Details
                {
                    Id = reader.GetInt32(0),
                    FirstName = reader.GetString(1),
                    LastName = reader.GetString(2),
                    Email = reader.GetString(3),
                    Password = reader.GetString(4),
                    Phone = reader.GetString(5),
                    Date = DateOnly.FromDateTime(reader.GetDateTime(6)),
                    Address = reader.GetString(7),
                    Sem = reader.GetString(8)
                };
                conn.Close();
                return Ok(listItem);
            }
            else
            {
                return BadRequest();
            } 
        }



        [HttpPut]
        [Route("{id}")]
        public ActionResult<Details> UpdateData(int id, Details details)
        {
            SqlConnection conn = new SqlConnection(SqlConnetionstring);
            string query = "Update Details set FirstName = @fname ,LastName = @lname ,Email=@email,Password = @pws,Phone=@phone," +
                                        "Date = @date,Address = @address,Sem = @sem Where Id = @id";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@id" , id);
            cmd.Parameters.AddWithValue("@fname" , details.FirstName);
            cmd.Parameters.AddWithValue("@lname" , details.LastName);
            cmd.Parameters.AddWithValue("@email" , details.Email);
            cmd.Parameters.AddWithValue("@pws" , details.Password);
            cmd.Parameters.AddWithValue("@phone" , details.Phone);
            cmd.Parameters.AddWithValue("@date" , details.Date);
            cmd.Parameters.AddWithValue("@address" , details.Address);
            cmd.Parameters.AddWithValue("@sem" , details.Sem);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            return Ok( new { message = "data updated", details });           
        }



        [HttpDelete]
        [Route("{id}")]
        public ActionResult DeleteData(int id)
        {
            SqlConnection conn = new SqlConnection(SqlConnetionstring);
            string query = "Delete From Details Where Id = @id";
            SqlCommand command = new SqlCommand(query, conn);
            command.Parameters.AddWithValue ("@id" , id);
            conn.Open();
            command.ExecuteNonQuery();
            conn.Close();
            return Ok(new { message = id + " Data deleted "});
        }
    }
}
