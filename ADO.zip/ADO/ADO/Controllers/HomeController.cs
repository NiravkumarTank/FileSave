﻿using System.Net;
using ADO.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using PdfSharpCore;
using PdfSharpCore.Pdf;
using TheArtOfDev.HtmlRenderer.PdfSharp;

namespace ADO.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        private readonly string SqlConnection = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ADO;Integrated Security=True;Trust Server Certificate=True";

        [HttpGet]
       public ActionResult<List<Product>> GetAll()
        {
            List<Product> products = new List<Product>();   

            SqlConnection conn = new SqlConnection(SqlConnection);
            string query = "select * from Product";
            SqlCommand cmd = new SqlCommand(query,conn);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Product product = new Product
                {
                    Id = (Int32)(reader[0]),
                    Name = (String)reader[1],
                    Address = (String)reader[2]
                };
                products.Add(product);
            }
            conn.Close();
            return products;
       }

        [HttpPost]
        public ActionResult<Product> AddData(Product product)
        {
            SqlConnection conn = new SqlConnection(SqlConnection);
            string query = "Insert into Product (Name,Address) Values (@name,@address)";
            SqlCommand command = new SqlCommand(query,conn);
            conn.Open();
            command.Parameters.AddWithValue("@name", product.Name);
            command.Parameters.AddWithValue("@address", product.Address);
            command.ExecuteNonQuery();
            conn.Close();
            return product;
        }

        [HttpPut]
        [Route("{id}")]
        public ActionResult<Product> UpdateData(int id,Product product)
        {
            SqlConnection conn = new SqlConnection(SqlConnection);
            //string query = "Update Product set Name = @name,Address=@address Where Id =" + id;
            string query = "Update Product set Name = @name,Address=@address Where Id = @id";
            SqlCommand command = new SqlCommand(query, conn);
            conn.Open();
            command.Parameters.AddWithValue("@id", product.Id);
            command.Parameters.AddWithValue("@name", product.Name);
            command.Parameters.AddWithValue("@address", product.Address);
            command.ExecuteNonQuery();
            conn.Close();
            return product;
        }

        [HttpDelete]
        [Route("{id}")]
        public ActionResult    DeleteData(int id)
        {
            SqlConnection conn = new SqlConnection(SqlConnection);
            //string query = "Update Product set Name = @name,Address=@address Where Id =" + id;
            string query = "delete from Product Where Id = @id";
            SqlCommand command = new SqlCommand(query, conn);
            conn.Open();
            command.Parameters.AddWithValue("@id", id);
          
            command.ExecuteNonQuery();
            conn.Close();
            return Ok(new { message = id + "   Delete data"});
        }

        [HttpPost]
        public async Task<ActionResult<Product>> AddDataWithImageName([FromForm] Product product)
        {
            SqlConnection conn = new SqlConnection(SqlConnection);
            if (product.Address != null)
            {
                var path = Path.Combine(Directory.GetCurrentDirectory(), "Upload");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                var filePath = Path.Combine(path, $"{Guid.NewGuid()}_{Path.GetFileName(product.Image.FileName)}");
                using (var fs = new FileStream(filePath, FileMode.Create))
                {
                    await product.Image.CopyToAsync(fs);
                }
                product.Address = Path.GetFileName(filePath);
            }
            string query = "Insert into Product (Name,Address) Values (@name,@address)";
            SqlCommand command = new SqlCommand(query, conn);
            command.Parameters.AddWithValue("@name", product.Name);
            command.Parameters.AddWithValue("@address", product.Address);
            conn.Open();
            int rows = await command.ExecuteNonQueryAsync();
            conn.Close();
            if (rows > 0)
            {
                return Ok(product);
            }
            else
            {
                return BadRequest(new { message = "record are not added" });
            }
        }

        [HttpGet]
        public ActionResult<List<Product>> GetAllWithImage()
        {
            List<Product> products = new List<Product>();
            SqlConnection conn = new SqlConnection(SqlConnection);
            string query = "select * from Product";
            SqlCommand cmd = new SqlCommand(query, conn);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Product product = new Product
                {
                    Id = (Int32)(reader[0]),
                    Name = (String)reader[1],
                    Address = (String)reader[2]
                };
                products.Add(product);
            }
            var demo = products.Select(item => new
            {
                item.Id,
                item.Name,
                Address = $"{Request.Scheme}:/{Request.Host}/Upload/{item.Address}",
            });
            conn.Close();
            return Ok(demo);
        }


        [HttpDelete]
        [Route("{id}")]
        public ActionResult DeleteDataWithImage(int id)
        {
            SqlConnection conn = new SqlConnection(SqlConnection);

            string query = "Select Address from Product where Id = @id";
            
            SqlCommand cmd1 = new SqlCommand(query, conn);
            cmd1.Parameters.AddWithValue("@id", id);
            conn.Open();
            string selectImage = Convert.ToString(cmd1.ExecuteScalar());
            if (selectImage  == null)
            {
                return NotFound(new {message = $"image with this id are not found : {id}" });
            }
            var imagePath = Path.Combine(Directory.GetCurrentDirectory(),"Upload",selectImage);

            if (System.IO.File.Exists(imagePath))
            {
                System.IO.File.Delete(imagePath);
            }
            string query1 = "delete from Product Where Id = @id";
            SqlCommand command1 = new SqlCommand(query1, conn);
           
            command1.Parameters.AddWithValue("@id", id);

            command1.ExecuteNonQuery();
            conn.Close();
            return Ok(new { message = id + "   Delete data" });
        }

        [HttpPut]
        public async Task<ActionResult<Product>> UpdateDataWithImage([FromForm] Product product)
        {
            SqlConnection conn = new SqlConnection(SqlConnection);

            string query = "Select Address from Product where Id = @id";
            SqlCommand cmd1 = new SqlCommand(query, conn);
            cmd1.Parameters.AddWithValue("@id", product.Id);

            conn.Open();
            string selectImage = Convert.ToString(await cmd1.ExecuteScalarAsync());

            if (selectImage == null)
            {
                return NotFound(new { message = $"Image with this ID not found: {product.Id}" });
            }
            var imagePath = Path.Combine(Directory.GetCurrentDirectory(), "Upload", selectImage);

            if (System.IO.File.Exists(imagePath))
            {
                System.IO.File.Delete(imagePath);
            }

           
            if (product.Image != null)
            {
                var path = Path.Combine(Directory.GetCurrentDirectory(), "Upload");
          

                var updatepath = Path.Combine(path, $"{Guid.NewGuid()}_{Path.GetFileName(product.Image.FileName)}");

                using (var fs = new FileStream(updatepath, FileMode.Create))
                {
                    await product.Image.CopyToAsync(fs);
                }
                product.Address = Path.GetFileName(updatepath);
                string query1 = "Update Product set Name = @name, Address = @address Where Id = @id";
                SqlCommand command = new SqlCommand(query1, conn);
                command.Parameters.AddWithValue("@id", product.Id);
                command.Parameters.AddWithValue("@name", product.Name);
                command.Parameters.AddWithValue("@address", product.Address);

                await command.ExecuteNonQueryAsync();
                return Ok(product);
            }
         
            conn.Close();
            return BadRequest();
        }


        [HttpGet]
        [Route("{id:int}")]
        public  IActionResult GetPdf(int id)
        {

            List<Product> list = new List<Product>();

            SqlConnection conn = new SqlConnection(SqlConnection);
            try
            {


                string query = "Select * from Product where Id = @id";
                conn.Open();
                SqlCommand cmd1 = new SqlCommand(query, conn);
                cmd1.Parameters.AddWithValue("@id", id);



                SqlDataReader reader =  cmd1.ExecuteReader();
                if (reader.Read())
                {
                    var listItem = new Product
                    {
                        Id = reader.GetInt32(0),
                        Name = reader.GetString(1),
                        Address = reader.GetString(2),
                    };
                    list.Add(listItem);
                }


                var demo = new
                {
                    list[0].Id,
                    list[0].Name,
                    Address1 = $"{Request.Scheme}://{Request.Host}/Upload/{list[0].Address}",

                };

                string htmlData = $@"<h1>Name = {demo.Name} and Id = {demo.Id} <h1> ";
                htmlData += $"<img src='{demo.Address1}' width='500' height='500'/>   ";

                var document = new PdfDocument();
                PdfGenerator.AddPdfPages(document, htmlData, PageSize.A4);

                byte[]? res;
                using (MemoryStream ms = new MemoryStream())
                {
                    document.Save(ms);
                    res = ms.ToArray();
                }

                // Generate the filename based on the product Id
                string filename = $"data_{list[0].Name}.pdf";
            

                // Return the generated PDF file
                return File(res, "application/pdf", filename);

            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
            finally
            {
                conn.Close();
            }



        }


    }
}
